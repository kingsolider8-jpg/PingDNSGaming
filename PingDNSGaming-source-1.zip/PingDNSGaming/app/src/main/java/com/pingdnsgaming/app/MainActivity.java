package com.pingdnsgaming.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13, 20, 29), card = Color.rgb(24, 35, 47), mint = Color.rgb(85, 230, 165), white = Color.WHITE;
    private TextView status;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(28), dp(22), dp(24)); scroll.addView(root);
        TextView logo = text("PING DNS", 30, mint, true); root.addView(logo);
        TextView subtitle = text("GAMING • NETWORK TOOLS", 13, Color.LTGRAY, true); subtitle.setPadding(0, dp(4),0,dp(22)); root.addView(subtitle);
        TextView title = text("سلام گیمر! 🎮", 24, white, true); root.addView(title);
        TextView desc = text("ابزار ساده برای بررسی اتصال و انتخاب DNS. توجه: DNS به‌تنهایی تضمین نمی‌کند پینگ بازی کمتر شود.", 15, Color.LTGRAY, false); desc.setPadding(0,dp(10),0,dp(20)); root.addView(desc);
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(16),dp(16),dp(16),dp(16)); panel.setBackgroundColor(card); root.addView(panel);
        panel.addView(text("آزمون اتصال اینترنت",18,white,true));
        status = text("برای شروع، دکمه زیر را بزن.",15,Color.LTGRAY,false); status.setPadding(0,dp(12),0,dp(12)); panel.addView(status);
        Button test = button("بررسی زمان پاسخ DNS", mint, bg); panel.addView(test);
        test.setOnClickListener(v -> runTest());
        TextView dnsTitle = text("DNSهای عمومی پیشنهادی",18,white,true); dnsTitle.setPadding(0,dp(24),0,dp(10)); root.addView(dnsTitle);
        root.addView(dnsCard("Cloudflare", "1.1.1.1  •  1.0.0.1"));
        root.addView(dnsCard("Google", "8.8.8.8  •  8.8.4.4"));
        root.addView(dnsCard("Quad9", "9.9.9.9  •  149.112.112.112"));
        TextView note = text("این برنامه تنظیمات DNS گوشی را خودکار تغییر نمی‌دهد. برای تنظیم دستی از بخش Private DNS اندروید استفاده کن؛ نتیجه و پینگ به اپراتور، وای‌فای و سرور بازی بستگی دارد.",13,Color.LTGRAY,false); note.setPadding(0,dp(18),0,dp(14)); root.addView(note);
        Button settings = button("باز کردن تنظیمات Private DNS", Color.rgb(39, 57, 73), white); root.addView(settings);
        settings.setOnClickListener(v -> { try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch(Exception e) { startActivity(new Intent(Settings.ACTION_SETTINGS)); } });
        setContentView(scroll);
    }
    private void runTest() {
        status.setText("در حال بررسی…");
        executor.execute(() -> {
            String result;
            try { long start = System.nanoTime(); InetAddress.getAllByName("one.one.one.one"); long ms = (System.nanoTime()-start)/1_000_000; result = "پاسخ DNS دریافت شد: حدود " + ms + " ms\nاین مقدار فقط زمان جست‌وجوی نام دامنه است، نه پینگ سرور بازی."; }
            catch(Exception e) { result = "آزمون ناموفق بود. اینترنت یا دسترسی DNS را بررسی کن."; }
            final String finalResult = result; runOnUiThread(() -> status.setText(finalResult));
        });
    }
    private View dnsCard(String name, String servers) { LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(14),dp(12),dp(14),dp(12)); box.setBackgroundColor(card); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=dp(8); box.setLayoutParams(lp); box.addView(text(name,16,white,true)); TextView val=text(servers,14,mint,false); val.setPadding(0,dp(5),0,0); box.addView(val); return box; }
    private Button button(String label,int color,int textColor) { Button b = new Button(this); b.setText(label); b.setTextColor(textColor); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); return b; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); t.setGravity(Gravity.START); return t; }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
