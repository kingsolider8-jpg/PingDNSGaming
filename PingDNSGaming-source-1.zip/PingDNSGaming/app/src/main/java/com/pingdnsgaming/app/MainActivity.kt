package com.pingdnsgaming.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.InetAddress
import java.util.concurrent.Executors
import kotlin.system.measureTimeMillis

class MainActivity : Activity() {
    private val bg = Color.rgb(4, 17, 19)
    private val panel = Color.rgb(10, 34, 36)
    private val green = Color.rgb(0, 214, 160)
    private val white = Color.rgb(242, 248, 247)
    private val muted = Color.rgb(167, 190, 188)
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var result: TextView
    private lateinit var spinner: Spinner

    data class DnsOption(val label: String, val address: String, val hostname: String)
    private val options = listOf(
        DnsOption("Cloudflare · 1.1.1.1", "1.1.1.1 / 1.0.0.1", "one.one.one.one"),
        DnsOption("Google · 8.8.8.8", "8.8.8.8 / 8.8.4.4", "dns.google"),
        DnsOption("Quad9 · 9.9.9.9", "9.9.9.9 / 149.112.112.112", "dns.quad9.net")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, stroke: Int = Color.TRANSPARENT): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(18).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(6), dp(5), dp(6), dp(5))
    }
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 15f; setTextColor(bg)
        background = rounded(green); setOnClickListener { action() }
        setPadding(dp(10), dp(8), dp(10), dp(8))
    }
    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(20), dp(20), dp(28)); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        scroll.addView(root)
        root.addView(text("PingDNS Gaming", 27f, green, true))
        root.addView(text("ابزار رایگان بررسی DNS برای بازی", 15f, muted))
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel, Color.rgb(20, 66, 63)); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(20)
        root.addView(hero, lp)
        hero.addView(text("سرور DNS را انتخاب کن", 18f, white, true))
        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options.map { it.label })
        }
        hero.addView(spinner, LinearLayout.LayoutParams(-1, dp(52)))
        result = text("یک سرور انتخاب کن و تست را بزن.", 15f, muted)
        val resLp = LinearLayout.LayoutParams(-1, -2); resLp.topMargin = dp(8)
        hero.addView(result, resLp)
        val test = button("تست پاسخ DNS", ::testDns)
        val btnLp = LinearLayout.LayoutParams(-1, dp(52)); btnLp.topMargin = dp(12)
        hero.addView(test, btnLp)
        val apply = button("تنظیم DNS خصوصی اندروید", ::openPrivateDns)
        val applyLp = LinearLayout.LayoutParams(-1, dp(52)); applyLp.topMargin = dp(10)
        hero.addView(apply, applyLp)
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val infoLp = LinearLayout.LayoutParams(-1, -2); infoLp.topMargin = dp(18)
        root.addView(info, infoLp)
        info.addView(text("چطور استفاده کنم؟", 18f, green, true))
        info.addView(text("۱. سرور را انتخاب کن.\n۲. «تست پاسخ DNS» را بزن تا زمان پاسخ نام دامنه اندازه‌گیری شود.\n۳. برای فعال‌سازی DNS رمزگذاری‌شده، تنظیمات Private DNS اندروید را باز کن و نام میزبان را وارد کن.", 14f, white))
        val note = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(Color.rgb(39, 25, 20), Color.rgb(135, 65, 42)); setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val noteLp = LinearLayout.LayoutParams(-1, -2); noteLp.topMargin = dp(14)
        root.addView(note, noteLp)
        note.addView(text("محدودیت مهم", 17f, Color.rgb(255, 166, 110), true))
        note.addView(text("این برنامه DNS را به‌صورت خودکار و سراسری عوض نمی‌کند؛ اندروید برای این کار تنظیمات سیستم یا پیاده‌سازی VPN لازم دارد. تست، پینگ سرور بازی نیست و کاهش پینگ تضمین نمی‌شود. برای Private DNS باید نام میزبان وارد شود، نه IP.", 13f, white))
        setContentView(scroll)
    }

    private fun testDns() {
        val chosen = options[spinner.selectedItemPosition]
        result.text = "در حال تست ${chosen.label} …"
        executor.execute {
            var total = 0L; var ok = 0
            repeat(3) {
                try {
                    val elapsed = measureTimeMillis { InetAddress.getByName("example.com") }
                    total += elapsed; ok++
                } catch (_: Exception) { }
            }
            val message = if (ok > 0) "پاسخ نام دامنه: میانگین ${total / ok} ms\nسرور انتخابی: ${chosen.address}\nتوجه: این تست از DNS فعال فعلی گوشی استفاده می‌کند؛ سرور انتخابی را مستقیماً اندازه نمی‌گیرد." else "تست ناموفق بود. اتصال اینترنت را بررسی کن."
            runOnUiThread { result.text = message }
        }
    }

    private fun openPrivateDns() {
        val chosen = options[spinner.selectedItemPosition]
        try {
            startActivity(Intent(Settings.ACTION_PRIVATE_DNS_SETTINGS))
            Toast.makeText(this, "نام میزبان برای ورود: ${chosen.hostname}", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "تنظیمات شبکه را باز کن و بخش Private DNS را پیدا کن. میزبان: ${chosen.hostname}", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
    }

    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}
