# PingDNSGaming

A simple Persian-language Android utility that lists public DNS providers, measures a DNS lookup duration, and opens Android network settings. DNS lookup time is not the same as game-server ping, and changing DNS does not guarantee lower latency.

## Build

Run `gradle assembleDebug` with Android SDK platform 35 and JDK 17 installed. GitHub Actions workflow `.github/workflows/android.yml` can build a debug APK manually from the Actions tab.

## Notes

- The app does not automatically change system DNS.
- The debug APK is not signed for Play Store release.
